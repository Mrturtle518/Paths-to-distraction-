const http=require("http"),fs=require("fs"),path=require("path"),{WebSocketServer}=require("ws");
const PORT=process.env.PORT||8080, players=new Map();
const mime={".html":"text/html",".js":"text/javascript",".css":"text/css"};
const server=http.createServer((req,res)=>{
  let p=req.url.split("?")[0]; if(p==="/")p="/index.html";
  const file=path.join(__dirname,p);
  if(!file.startsWith(__dirname)||!fs.existsSync(file)){res.writeHead(404);return res.end("Not found")}
  res.writeHead(200,{"Content-Type":mime[path.extname(file)]||"application/octet-stream","Cache-Control":"no-cache"});
  fs.createReadStream(file).pipe(res);
});
const wss=new WebSocketServer({server});
function broadcast(obj){const s=JSON.stringify(obj);for(const p of players.values())if(p.ws.readyState===1)p.ws.send(s)}
function publicState(){const out={};for(const [id,p] of players)out[id]={name:p.name,x:p.x,y:p.y,team:p.team,hp:p.hp,sh:p.sh};return out}
wss.on("connection",ws=>{
  const id=Math.random().toString(36).slice(2,10);
  const p={ws,id,name:"Player",x:Math.random()*900,y:Math.random()*700,team:1,hp:100,sh:50,mode:"BR"};
  players.set(id,p);ws.send(JSON.stringify({type:"welcome",id}));
  ws.on("message",raw=>{
    let m;try{m=JSON.parse(raw)}catch{return}
    if(m.type==="join"){p.name=String(m.name||"Player").slice(0,16);p.mode=m.mode||"BR";broadcast({type:"start",mode:p.mode,max:p.mode==="BR"?50:p.mode==="TDM"?12:Number(p.mode[0])*2})}
    if(m.type==="move"){p.x=Number(m.x)||p.x;p.y=Number(m.y)||p.y}
    if(m.type==="shoot"){broadcast({type:"shot",id,x:p.x,y:p.y,weapon:m.weapon})}
  });
  ws.on("close",()=>{players.delete(id);broadcast({type:"state",players:publicState()})});
});
setInterval(()=>broadcast({type:"state",players:publicState()}),100);
server.listen(PORT,()=>console.log("Paths to Distriction online server listening on "+PORT));
