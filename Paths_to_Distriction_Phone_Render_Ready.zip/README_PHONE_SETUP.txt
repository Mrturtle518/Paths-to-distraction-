PATHS TO DISTRICTION — PHONE + GITHUB + RENDER

This ZIP is prepared so the same Render web service can serve the browser game AND run the WebSocket multiplayer server.

PHONE SETUP
1. Extract this ZIP in the iPhone Files app.
2. Create a GitHub repository named paths-to-distriction.
3. Upload the files from this folder to the repository root:
   index.html
   style.css
   game.js
   server.js
   package.json
   render.yaml
   README_ONLINE.md
   README_PHONE_SETUP.txt
4. In Render, choose New > Web Service and connect the GitHub repository.
5. Build Command: npm install
6. Start Command: npm start
7. Deploy.
8. Open the Render HTTPS URL in Safari.

IMPORTANT
The game automatically uses the same host for WebSockets:
https://example.onrender.com -> wss://example.onrender.com
You do NOT need to edit a server URL.

If Render provides a different port, server.js already reads the PORT environment variable.

This is an early online multiplayer foundation. It is not yet a production-grade 50-player shooter. It still needs authoritative server simulation, rooms/matchmaking, synchronized combat, authentication, persistence, reconnects, lag compensation and anti-cheat.
