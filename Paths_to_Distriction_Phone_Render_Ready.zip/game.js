const c=document.getElementById("c"),g=c.getContext("2d"),mini=document.getElementById("mini").getContext("2d");let W,H,dpr;
const guns=[["Ranger AR",24,30,8],["Burst SMG",16,36,12],["Pump Shotgun",90,8,1.1],["Scout DMR",48,12,3]];
const skins=[["🍌","Sunny Split","Skin",800],["🐢🎩","Sir Shellington","Skin",1200],["🧑‍🚀","Sky Ranger","Skin",1000],["🕶️","Neon Runner","Skin",1400],["🪸","Reef Guardian","Skin",1100],["🥷","Night Scout","Skin",1300],["🎒","Trail Pack","Back Bling",400],["🚀","Mini Jetpack","Back Bling",700],["🐚","Golden Shell","Back Bling",600],["🍌","Banana Satchel","Back Bling",500],["⛏️","Trailblazer","Pickaxe",500],["🔨","Meteor Hammer","Pickaxe",800],["🔱","Tide Trident","Pickaxe",900],["❄️","Frost Shard","Pickaxe",700],["✨","Victory Spark","Emote",300],["👋","Wave Hello","Emote",200]];
let save=JSON.parse(localStorage.ptd3||"null")||{name:"Player",coins:9999999,owned:["Sunny Split","Sir Shellington","Banana Satchel","Trailblazer","Victory Spark"],eq:{Skin:"Sunny Split",Back:"Banana Satchel",Pickaxe:"Trailblazer"}};
let S={on:false,mode:"BR",max:50,alive:50,kills:0,t:0,storm:900,p:{x:0,y:0,hp:100,sh:50,w:0,a:[30,36,8,12],r:[120,144,32,48],cool:0},e:[],loot:[],build:[],pickup:0};
let joy={on:false,x:0,y:0},keys={};function resize(){dpr=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;c.width=W*dpr;c.height=H*dpr;g.setTransform(dpr,0,0,dpr,0,0)}addEventListener("resize",resize);resize();
function cfg(m){if(m=="BR")return[50,"BATTLE ROYALE"];if(m=="TDM")return[12,"TEAM DEATHMATCH"];return[+m[0]*2,m]}function start(m){let q=cfg(m);S={...S,on:true,mode:m,max:q[0],alive:q[0],kills:0,t:0,storm:Math.max(W,H)*.8,p:{x:0,y:0,hp:100,sh:50,w:0,a:guns.map(z=>z[2]),r:[120,144,32,48],cool:0},e:[],loot:[],build:[],pickup:0};for(let i=0;i<Math.min(24,q[0]-1);i++)S.e.push({x:Math.random()*W,y:Math.random()*H,hp:100,spd:12+Math.random()*18,attack:Math.random()});for(let i=0;i<30;i++)S.loot.push({x:Math.random()*W,y:Math.random()*H,t:i%4});for(let i=0;i<15;i++)S.build.push({x:Math.random()*W,y:Math.random()*H,w:40+Math.random()*55,h:30+Math.random()*45});lobby.classList.add("hidden");result.classList.add("hidden");hud.classList.remove("hidden");update();requestAnimationFrame(loop)}
function update(){mode.textContent=cfg(S.mode)[1];alive.textContent=`ALIVE ${S.alive}`;hp.style.width=S.p.hp+"%";document.querySelector(".shield").style.setProperty("--s",S.p.sh+"%");wn.textContent=guns[S.p.w][0];am.textContent=`${S.p.a[S.p.w]} / ${S.p.r[S.p.w]}`;slots.innerHTML=guns.map((z,i)=>`<button class="${i==S.p.w?"active":""}">${i+1}</button>`).join("");slots.querySelectorAll("button").forEach((b,i)=>b.onclick=()=>{S.p.w=i;update()})}
function fire(){if(!S.on||S.p.cool>0||S.p.a[S.p.w]<=0)return;let z=guns[S.p.w];S.p.a[S.p.w]--;S.p.cool=1/z[3];let target=null,bd=1e9;S.e.forEach(e=>{if(e.x<0)return;let d=Math.hypot(e.x-W/2,e.y-H/2);if(d<bd){bd=d;target=e}});if(target&&bd<210){target.hp-=z[1];if(target.hp<=0){target.x=-9999;S.kills++;S.alive--;notice.textContent=`ELIMINATION +1`;setTimeout(()=>notice.textContent="",800);if(S.mode=="BR"&&S.alive<=1)finish(true)}}update()}
function reload(){let i=S.p.w,z=guns[i],need=z[2]-S.p.a[i],take=Math.min(need,S.p.r[i]);S.p.a[i]+=take;S.p.r[i]-=take;update()}function heal(){if(S.p.sh<50){S.p.sh=Math.min(50,S.p.sh+25);S.p.hp=Math.max(1,S.p.hp-10);update()}}
function finish(win){S.on=false;hud.classList.add("hidden");result.classList.remove("hidden");resultTitle.textContent=win?"VICTORY!":"ELIMINATED";resultSub.textContent=`${save.name} • ${S.kills} eliminations • ${cfg(S.mode)[1]}`}
function move(dt){let dx=0,dy=0;if(keys.w)dy--;if(keys.s)dy++;if(keys.a)dx--;if(keys.d)dx++;if(joy.on){dx+=joy.x;dy+=joy.y}let l=Math.hypot(dx,dy)||1;S.p.x+=dx/l*170*dt;S.p.y+=dy/l*170*dt}
function updateGame(dt){S.t+=dt;S.p.cool=Math.max(0,S.p.cool-dt);move(dt);S.storm=Math.max(150,Math.max(W,H)*.8-S.t*6);
S.e.forEach(e=>{if(e.x<0)return;let dx=W/2-e.x,dy=H/2-e.y,d=Math.hypot(dx,dy)||1;e.x+=dx/d*e.spd*dt;e.y+=dy/d*e.spd*dt;if(d<38&&Math.random()<dt*.75){if(S.p.sh>0)S.p.sh=Math.max(0,S.p.sh-8);else S.p.hp-=8;if(S.p.hp<=0)finish(false)}});
S.loot.forEach(l=>{if(l.x<0)return;if(Math.hypot(l.x-W/2,l.y-H/2)<28){l.x=-9999;S.pickup++;if(l.t==0)S.p.r[S.p.w]+=30;if(l.t==1)S.p.sh=Math.min(50,S.p.sh+20);if(l.t==2)S.p.hp=Math.min(100,S.p.hp+20);if(l.t==3)S.p.a[S.p.w]=guns[S.p.w][2]}});
if(S.mode!="BR"&&S.alive>1&&Math.random()<dt*.25)S.alive--;if(S.mode!="BR"&&S.alive<=1)finish(true);update()}
function draw(){g.fillStyle="#1c5532";g.fillRect(0,0,W,H);g.fillStyle="#28683d";for(let x=-(S.p.x%55);x<W;x+=55)g.fillRect(x,0,2,H);for(let y=-(S.p.y%55);y<H;y+=55)g.fillRect(0,y,W,2);g.strokeStyle="#77694e";g.lineWidth=18;g.beginPath();g.moveTo(0,H*.75);g.lineTo(W,H*.15);g.stroke();
S.build.forEach(b=>{g.fillStyle="#806b53";g.fillRect(b.x,b.y,b.w,b.h);g.fillStyle="#574438";g.fillRect(b.x+5,b.y+5,b.w-10,7)});S.loot.forEach(l=>{if(l.x<0)return;g.fillStyle=["#e1b73d","#3c9fce","#d66d42","#8d60bd"][l.t];g.fillRect(l.x-7,l.y-7,14,14)});S.e.forEach(e=>{if(e.x<0)return;g.fillStyle="#d44940";g.beginPath();g.arc(e.x,e.y,15,0,7);g.fill();g.fillStyle="#fff";g.fillRect(e.x-5,e.y-22,10,3)});g.fillStyle="#4b398955";g.beginPath();g.rect(0,0,W,H);g.arc(W/2,H/2,S.storm,0,7);g.fill("evenodd");g.fillStyle="#4aa9ff";g.beginPath();g.arc(W/2,H/2,18,0,7);g.fill();g.fillStyle="#fff";g.font="12px Arial";g.textAlign="center";g.fillText(save.eq.Skin,W/2,H/2-25);
mini.clearRect(0,0,100,100);mini.fillStyle="#225a37";mini.fillRect(0,0,100,100);mini.fillStyle="#d54a40";S.e.forEach(e=>{if(e.x>=0){mini.fillRect(e.x/W*100,e.y/H*100,2,2)}});mini.fillStyle="#4aa9ff";mini.fillRect(49,49,3,3)}
let last=performance.now();function loop(now){let dt=Math.min(.05,(now-last)/1000);last=now;if(S.on)updateGame(dt);draw();if(S.on)requestAnimationFrame(loop)}
document.querySelectorAll(".modes button").forEach(b=>b.onclick=()=>start(b.dataset.m));fire.onclick=fire;reload.onclick=reload;heal.onclick=heal;quit.onclick=()=>{S.on=false;hud.classList.add("hidden");lobby.classList.remove("hidden")};again.onclick=()=>start(S.mode);lobbyBtn.onclick=()=>{result.classList.add("hidden");lobby.classList.remove("hidden")};
name.value=save.name;name.onchange=e=>{save.name=e.target.value||"Player";localStorage.ptd3=JSON.stringify(save)};
function shopRender(){coins.textContent=`Coins: ${save.coins.toLocaleString()}`;shopItems.innerHTML=skins.map(a=>`<div class="item"><span>${a[0]} ${a[1]} <small>${a[2]}</small></span><button data-i="${a[1]}">${save.owned.includes(a[1])?"OWNED":a[3]+" 🪙"}</button></div>`).join("");shopItems.querySelectorAll("button").forEach(b=>b.onclick=()=>{let a=skins.find(z=>z[1]==b.dataset.i);if(!save.owned.includes(a[1])&&save.coins>=a[3]){save.coins-=a[3];save.owned.push(a[1]);localStorage.ptd3=JSON.stringify(save);shopRender()}})}
function lockerRender(){lockerItems.innerHTML=save.owned.map(n=>{let a=skins.find(z=>z[1]==n);return `<div class="item"><span>${a?a[0]:""} ${n}</span><button data-n="${n}">EQUIP</button></div>`}).join("");lockerItems.querySelectorAll("button").forEach(b=>b.onclick=()=>{let a=skins.find(z=>z[1]==b.dataset.n);if(a){save.eq[a[2].replace(" ","")]=a[1];localStorage.ptd3=JSON.stringify(save)}})}
shopBtn.onclick=()=>{shopRender();shop.classList.remove("hidden")};lockerBtn.onclick=()=>{lockerRender();locker.classList.remove("hidden")};document.querySelectorAll(".close").forEach(b=>b.onclick=()=>b.parentElement.classList.add("hidden"));
addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if(e.key==" ")fire();if(e.key=="r")reload();if("1234".includes(e.key)){S.p.w=+e.key-1;update()}});addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
joy.addEventListener("pointerdown",e=>{joy.on=true;joyMove(e)});joy.addEventListener("pointermove",e=>{if(joy.on)joyMove(e)});joy.addEventListener("pointerup",()=>{joy.on=false;joy.x=joy.y=0;nubReset()});function joyMove(e){let r=joy.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),l=Math.min(45,Math.hypot(dx,dy)),a=Math.atan2(dy,dx);joy.x=Math.cos(a)*l/45;joy.y=Math.sin(a)*l/45;document.querySelector("#joy i").style.transform=`translate(${joy.x*45}px,${joy.y*45}px)`}function nubReset(){document.querySelector("#joy i").style.transform=""}
addEventListener("pointerdown",e=>{if(e.target==c)fire()});draw();

// ONLINE MULTIPLAYER EXTENSION
const ONLINE_SERVER = window.PTD_SERVER_URL ||
  ((location.protocol === "https:" ? "wss://" : "ws://") + location.host);
let net=null, netId=null, netPlayers={};
function connectOnline(){
  try{
    net=new WebSocket(ONLINE_SERVER);
    net.onopen=()=>{ if(typeof save!=="undefined") net.send(JSON.stringify({type:"join",name:save.name,mode:S.mode})); };
    net.onmessage=e=>{
      const m=JSON.parse(e.data);
      if(m.type==="welcome"){netId=m.id; document.getElementById("notice").textContent="ONLINE • CONNECTED";}
      if(m.type==="state"){
        netPlayers=m.players||{};
        const count=Object.keys(netPlayers).length;
        S.alive=Math.max(S.alive,count);
        update();
      }
      if(m.type==="start"){S.mode=m.mode; S.max=m.max; S.alive=m.max;}
      if(m.type==="hit" && m.target===netId){S.p.hp=m.hp;S.p.sh=m.sh;if(S.p.hp<=0)finish(false);}
    };
    net.onclose=()=>{if(S.on)document.getElementById("notice").textContent="SERVER OFFLINE • BOT MODE";};
  }catch(e){}
}
const oldStart=start;
start=function(m){oldStart(m); connectOnline();};
const oldDraw=draw;
draw=function(){
  oldDraw();
  if(!netPlayers)return;
  for(const id in netPlayers){
    if(id===netId)continue;
    const p=netPlayers[id];
    if(!p)continue;
    ctx.fillStyle=p.team===1?"#49a9ff":"#e04b43";
    ctx.beginPath();ctx.arc(p.x,p.y,16,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#fff";ctx.font="10px Arial";ctx.textAlign="center";ctx.fillText(p.name||"Player",p.x,p.y-23);
  }
};
const oldFire=fire;
fire=function(){oldFire(); if(net&&net.readyState===1)net.send(JSON.stringify({type:"shoot",weapon:S.p.w,x:W/2,y:H/2}));};
const oldMove=move;
move=function(dt){
  oldMove(dt);
  if(net&&net.readyState===1)net.send(JSON.stringify({type:"move",x:W/2,y:H/2}));
};
