# Paths to Distriction — Online V1 (Phone/Render Ready)

## Deploy from a phone
Upload the repository files to GitHub, then create a Render Web Service from that repository.

Build:
`npm install`

Start:
`npm start`

The browser client automatically chooses `wss://<your-render-host>` when served over HTTPS, so no URL editing is required.

## Local
`npm install`
`npm start`
Open `http://localhost:8080`.

## Multiplayer status
The WebSocket layer supports player presence, basic movement messages and shooting events. It is an early foundation and does not yet provide production-grade authoritative combat, matchmaking, persistent accounts, anti-cheat, lag compensation, or scalable 50-player instances.
